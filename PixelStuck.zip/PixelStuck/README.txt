Bottom right are two gadgets button, click to use
Left one is hook, press it and press arrow key of desired hook direction to pull that block one tile closer to you. Click button again to move
The other is swap, press it and click two 3x3 squares (separated by red grid) to swap. Auto deselects after one swap. 
Arrow keys to move, space to jump